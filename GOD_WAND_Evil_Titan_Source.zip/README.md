# GOD WAND – Evil Titan Edition (Paper plugin source)

This is a **source project**, not a compiled or tested JAR. It targets Paper 1.21.11 and Java 21.

## Features
- Crafting recipe: Nether Star / Amethyst Shard / Blaze Rod in the configured vertical pattern.
- Right-click air/block with the wand: Strength II, Speed II, Resistance I for 5 minutes (no OP permission is granted).
- Right-click a player: kick (configurable).
- Automatic ban only when a player dies to a player holding the GOD WAND. There is **no manual ban ability**.
- Evil Aura pushes nearby entities, items and projectiles away within the configured radius.
- Hand aura particles while holding the wand.
- Water aura is visual particles only when the holder is in water; it does not delete water blocks or alter terrain.
- No cooldown.

## Build
Install a Java 21 JDK and Maven. From this folder run:
```bash
mvn package
```
The JAR should be created at `target/godwand-1.1.0.jar`. Put that JAR into your Paper server's `plugins` folder and restart.

## Notes
- This project has not been compiled or tested against a live Paper server here. Verify on a test server first.
- One JAR is not guaranteed to work on every Paper version; this project targets Paper 1.21.11.
- The kick and automatic-ban features can disrupt a public server. Keep trusted staff protected with `godwand.protected`, and consider disabling these features in `config.yml`.
- Water blocks are deliberately not removed: deleting world blocks around a moving player can damage builds and terrain.
