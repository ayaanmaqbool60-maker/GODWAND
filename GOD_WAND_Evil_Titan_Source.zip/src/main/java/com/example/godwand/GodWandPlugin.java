package com.example.godwand;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.ban.BanList;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Date;
import java.util.UUID;

public final class GodWandPlugin extends JavaPlugin implements Listener {
    private NamespacedKey wandKey;

    @Override public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "god_wand");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("godwand") != null) getCommand("godwand").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
            if (args.length == 1 && args[0].equalsIgnoreCase("give")) {
                player.getInventory().addItem(createWand());
                player.sendMessage(ChatColor.LIGHT_PURPLE + "GOD WAND received!");
            } else player.sendMessage(ChatColor.YELLOW + "Use /godwand give");
            return true;
        });
        addRecipe();
        startAuraTask();
        getLogger().info("GOD WAND - Evil Titan Edition enabled.");
    }

    private ItemStack createWand() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "GOD WAND");
        meta.setLore(java.util.List.of(
            ChatColor.LIGHT_PURPLE + "Evil Titan Edition",
            ChatColor.GRAY + "Right-click: Titan powers",
            ChatColor.GRAY + "Right-click a player: Kick",
            ChatColor.GRAY + "Wand kill: Automatic ban",
            ChatColor.DARK_PURPLE + "Zero cooldown"
        ));
        meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isWand(ItemStack item) {
        return item != null && item.getType() == Material.BLAZE_ROD && item.hasItemMeta()
            && item.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    private void addRecipe() {
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(this, "god_wand_recipe"), createWand());
        recipe.shape("N  ", " A ", " B ");
        recipe.setIngredient('N', Material.NETHER_STAR);
        recipe.setIngredient('A', Material.AMETHYST_SHARD);
        recipe.setIngredient('B', Material.BLAZE_ROD);
        getServer().addRecipe(recipe);
    }

    @EventHandler(ignoreCancelled = true)
    public void onUse(PlayerInteractEvent event) {
        if (!isWand(event.getItem())) return;
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR &&
            event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        int ticks = Math.max(1, getConfig().getInt("power-duration-seconds", 300)) * 20;
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, ticks, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, ticks, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, ticks, 0));
        player.getWorld().spawnParticle(Particle.DRAGON_BREATH, player.getLocation().add(0, 1, 0), 45, .8, .8, .8, .03);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1f, .7f);
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Evil Titan powers activated!");
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerRightClick(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Player target) || !isWand(event.getPlayer().getInventory().getItem(event.getHand()))) return;
        Player user = event.getPlayer();
        if (!getConfig().getBoolean("kick-enabled", true)) return;
        if (target.hasPermission("godwand.protected")) {
            user.sendMessage(ChatColor.RED + "That player is protected.");
            return;
        }
        target.kickPlayer(ChatColor.DARK_PURPLE + "You were kicked by the GOD WAND.");
        user.sendMessage(ChatColor.LIGHT_PURPLE + "GOD WAND: player kicked.");
    }

    @EventHandler
    public void onWandKill(PlayerDeathEvent event) {
        if (!getConfig().getBoolean("auto-ban-on-wand-kill", true)) return;
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || !holdsWand(killer) || victim.hasPermission("godwand.protected")) return;
        Bukkit.getBanList(BanList.Type.NAME).addBan(victim.getName(),
            "Automatic GOD WAND ban: killed by a GOD WAND holder.", (Date) null, killer.getName());
        Bukkit.getScheduler().runTask(this, () -> Bukkit.getPlayer(victim.getUniqueId()) == null ? null :
            Bukkit.getPlayer(victim.getUniqueId()).kickPlayer(ChatColor.DARK_PURPLE + "Automatic GOD WAND ban."));
        killer.sendMessage(ChatColor.LIGHT_PURPLE + victim.getName() + " was automatically banned.");
    }

    private boolean holdsWand(Player player) {
        return isWand(player.getInventory().getItemInMainHand()) || isWand(player.getInventory().getItemInOffHand());
    }

    private void startAuraTask() {
        new BukkitRunnable() {
            @Override public void run() {
                for (Player holder : Bukkit.getOnlinePlayers()) {
                    if (!holdsWand(holder)) continue;
                    Location base = holder.getLocation();
                    if (getConfig().getBoolean("hand-aura-enabled", true)) spawnHandAura(holder);
                    if (getConfig().getBoolean("water-aura-particles-enabled", true) && isInWater(holder))
                        holder.getWorld().spawnParticle(Particle.SPLASH, base, 18, .7, .5, .7, .02);
                    if (!getConfig().getBoolean("evil-aura-enabled", true)) continue;
                    double radius = Math.max(1, getConfig().getDouble("aura-radius", 8.0));
                    double strength = getConfig().getDouble("push-strength", 1.35);
                    for (Entity entity : holder.getNearbyEntities(radius, radius, radius)) {
                        if (entity.equals(holder) || entity instanceof ArmorStand) continue;
                        if (entity instanceof Player other && other.hasPermission("godwand.protected")) continue;
                        if (entity instanceof Item && !getConfig().getBoolean("item-repel-enabled", true)) continue;
                        if ((entity instanceof Projectile) && !getConfig().getBoolean("projectile-repel-enabled", true)) continue;
                        Vector direction = entity.getLocation().toVector().subtract(base.toVector());
                        if (direction.lengthSquared() < 0.01) direction = new Vector(0, 0.2, 0);
                        direction.normalize().multiply(strength);
                        direction.setY(Math.max(.25, direction.getY() + .25));
                        entity.setVelocity(direction);
                        entity.getWorld().spawnParticle(Particle.PORTAL, entity.getLocation().add(0, .5, 0), 5, .25, .3, .25, .02);
                    }
                }
            }
        }.runTaskTimer(this, 1L, 5L);
    }

    private boolean isInWater(Player player) {
        Material feet = player.getLocation().getBlock().getType();
        Material head = player.getEyeLocation().getBlock().getType();
        return feet == Material.WATER || head == Material.WATER;
    }

    private void spawnHandAura(Player player) {
        Location eye = player.getEyeLocation();
        Vector forward = eye.getDirection().normalize();
        Vector side = new Vector(-forward.getZ(), 0, forward.getX()).normalize();
        Location hand = eye.getLocation().add(forward.multiply(.45)).add(side.multiply(.28)).add(0, -.45, 0);
        player.getWorld().spawnParticle(Particle.DRAGON_BREATH, hand, 7, .12, .16, .12, .01);
        player.getWorld().spawnParticle(Particle.PORTAL, hand, 5, .16, .18, .16, .02);
    }
}
